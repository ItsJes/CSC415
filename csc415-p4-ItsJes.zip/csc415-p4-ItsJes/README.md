# CSC 415 - Project 4 - Thread Racing

## Student Name: Jessica Sendejo

## Student ID :  917443181

## Build Instructions
Built program with gcc -I -Wall pthread_race.c -o threadracer -pthread

## Run Instructions
Ran program with ./threadracer

## Explain why your program produces the wrong output
I believe that the programs produces wrong output because 
in the adder and subtractor functions the shared global variable
is being modified through each iteration of the for loops. It causes random
access to the variable random. I also believe that it can read the same value
but produces a different outcome with causes race conditions. Also, as I experiment 
by putting nanosleep() in different places in the program, I noticed that the output
would change. I believe that this interrupt causes the threading to access at random.