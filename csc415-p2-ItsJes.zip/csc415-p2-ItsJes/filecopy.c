#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>

#define BUFF_MAX 13

#define NAME "Jessica"

int main()
{
	char *buff[BUFF_MAX];
	char src[30], dest[30], userInput[20];
	int in, out, openFile, writeFile;

	printf("Welcome to the File Copy Program by %s! \n", NAME);
	printf("Enter the name of the file to copy from: ");
	scanf("%s", src);
	openFile = open(src, O_RDONLY);
	if (openFile == -1)
	{
		perror("File Not Found");
		exit(2);
	}

	printf("Enter the name of the file to copy to: ");
	scanf("%s", dest);
	writeFile = open(dest, O_WRONLY);

	if (!(writeFile == -1))
	{
		printf("File already exist. Would you like to overright the existing file? (yes or no) ");
		scanf("%s", userInput);
		if (!strcmp(userInput, "yes"))
			writeFile = open(dest, O_WRONLY | O_CREAT | O_TRUNC);
		else
		{
			printf("Programming closing! \n");
			exit(0);
		}
	}

	writeFile = open(dest, O_WRONLY | O_CREAT);

	while (1)
	{
		in = read(openFile, buff, BUFF_MAX);
		if (in <= 0)
			break;
		out = write(writeFile, buff, in);
		if (out <= 0)
			break;
	}

	close(openFile);
	close(writeFile);

    return 0;
}