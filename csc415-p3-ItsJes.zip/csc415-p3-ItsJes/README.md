# CSC 415 - Project 3 - My Shell

## Student Name: Jessica Sendejo

## Student ID: 917443181

## Build Instructions
gcc -I -Wall myshell.c -o myshell

## Run Instructions
./myshell

## List Extra Credits comepleted (if non attempted leave blank)
