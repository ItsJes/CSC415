/****************************************************************
 * Name        : Jessica Sendejo                                *
 * Class       : CSC 415                                        *
 * Date        :                                                *
 * Description :  Writting a simple bash shell program          *
 *                that will execute simple commands. The main   *
 *                goal of the assignment is working with        *
 *                fork, pipes and exec system calls.            *
 ****************************************************************/

#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <readline/readline.h>
#include <sys/wait.h>
#include <fcntl.h>

#define BUFFERSIZE 256
#define PROMPT "myShell >> "
#define PROMPTSIZE sizeof(PROMPT)

/*escape sequence for clearing the shell.*/
#define clear() printf("\033[H\033[J")

void init()
{
	clear();
	printf("\n\n******************************");
	printf("\n\t~*Jess's Shell*~");
	printf("\n\t   ~*CSC 415*~");
	printf("\n\n******************************\n\n\n\n\n\n");
	sleep(1);
}

void currentDir()
{
	char cwd[BUFFERSIZE];
	getcwd(cwd, sizeof(cwd));
	printf("myShell:%s", cwd); 
}

char *readLine(void)
{
	char *line = NULL;
	ssize_t bufsize = BUFFERSIZE;
	getline(&line, &bufsize, stdin);

	return line;
}

char **getInput(char *input)
{
	char **command = malloc(BUFFERSIZE * sizeof(char*));
	char *space = " ";
	char *parse;
	int index = 0;
	if (command == NULL)
	{
		perror("malloc has failed");
		exit(1);
	}

	parse = strtok(input, space);
	while (parse != NULL)
	{
		command[index] = parse;
		index++;

		if (!command)
		{
			perror("Error in allocation");
			exit(1);
		}

		parse = strtok(NULL, space);
	}

	command[index] = NULL;
	return command;
}

int runCommand(char** command)
{
	pid_t pid = fork();

	if (pid < 0)
	{
		perror("Fork Failed");
    }

	else if (pid == 0) 
	{
		execvp(command[0], command);
		perror("Execution Failed");
		exit(EXIT_FAILURE);
	}

	else 
	{
		wait(NULL);
	}

	return 1;
}

int builtIn(char **path)
{
	char *commandList[] = {"exit", "cd"};
	int length = sizeof(commandList) / sizeof(commandList[0]);
	int commandSwitch = 0;
	int i;

	for (i = 0; i < length; i++)
	{
		if (strcmp(path[0], commandList[i]) == 0)
		{
			commandSwitch = i + 1;
			break;
		}
	}
	
	switch (commandSwitch)
	{
	case 1: 
		printf("Good-Bye");
		exit(0);
	case 2: 
		chdir(path[1]);
		return 1;
	default:
		break;
	}

	return runCommand(path);
}

void pipeExecute(char **command, char **commandPipe)
{
	pid_t pid1;
	pid_t pid2;
	int pipefd[2];

	pipe(pipefd);

	pid1 = fork();
	if (pid1 == 0)
	{
		dup2(pipefd[1], STDOUT_FILENO);
		close(pipefd[0]);

		execvp(command[0], command);
		perror("Execution Failed");
		exit(EXIT_FAILURE);

		return;
	}

	pid2 = fork();
	if (pid2 == 0)
	{
		dup2(pipefd[1], STDOUT_FILENO);
		close(pipefd[0]);

		execvp(commandPipe[0], commandPipe);
		perror("Execution Failed");
		exit(EXIT_FAILURE);

		return;
	}

	close(pipefd[0]);
	close(pipefd[1]);

	wait(NULL);
	wait(NULL);
}

void shell_loop(void)
{
	char* input;
	char** args;
	int status;


	do
	{
		currentDir();
		printf(" >> ");
		input = readLine();
		args = getInput(input);
		status = builtIn(args);

		free(input);
		free(args);
	} while (status);
}

int main()
{

	init();
	shell_loop();
	return 0;
}
