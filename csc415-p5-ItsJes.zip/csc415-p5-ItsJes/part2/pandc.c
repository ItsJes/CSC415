#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <ctype.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <semaphore.h>

int *buff;
int buffIndex;
int N;
int P;
int C; 
int X;
int Ptime;
int Ctime;
int count;
int numConsumed;

pthread_mutex_t lock;
sem_t full;
sem_t empty;

pthread_t *tid_1;
pthread_t *tid_2;
pthread_attr_t attr;

int* producerArray;
int* consumerArray;
int Pindex;
int Cindex;

/* 
 * Function to remove item.
 * Item removed is returned
 */

void* producer(int *id)
{
	int item;
	int counter = 0;

	while(counter < X)
	{
		sem_wait(&empty);
		pthread_mutex_lock(&lock);   /* lock */

		item = count++; 
		printf("%d was produced by producer -> %d\n", item, *id);
		producerArray[Pindex++] = item;

		item = enqueue_item(N);
		counter++;
		
		sleep(Ptime); 

		pthread_mutex_unlock(&lock);   /* unlock */
		sem_post(&full);

	} 

	pthread_exit(0);
}

void* consumer(int *id)
{
	int item;

	int counter = 0;

	while(counter < numConsumed)
	{
		sem_wait(&full);
		pthread_mutex_lock(&lock);   /* lock */

		item = buff[--buffIndex];
		printf("%d was consumed by consumer -> %d\n", item, *id);

		producerArray[Cindex++] = item;
		
		counter++;


		sleep(Ctime);

		pthread_mutex_unlock(&lock);   /* unlock */
		sem_post(&empty);

	}

	pthread_exit(0);
}

int dequeue_item()
{
	return buff[--buffIndex];
}
/* 
 * Function to add item.
 * Item added is returned.
 * It is up to you to determine
 * how to use the ruturn value.
 * If you decide to not use it, then ignore
 * the return value, do not change the
 * return type to void. 
 */
int enqueue_item(int item)
{
	if (buffIndex < N)
	{
		buff[buffIndex++] = item;
		return 0;
	}
	else
		return -1;
	

	/*
	int counter;

	if (index < N)
	{
		buff[index++] = item;
		counter++;
		return counter;
	}

	else
		return -1;
	*/
}

int cmpFunc(const void * a, const void * b) 
{
	return (*(int*)a - *(int*)b);
}

int matchFunc(int n, int m)
{
	int i;
	if (n != m)
		return 0;

	for (i = 0; i < n; i++)
	{
		if (producerArray[i] != consumerArray[i])
			return 0;
	}

	return 1;
}

void printArray(int n, int m)
{
	int i;

	qsort(producerArray, n, sizeof(int), cmpFunc);
	qsort(consumerArray, m, sizeof(int), cmpFunc);

	printf("Producer Array | Consumer Array");
	for (i = 0; i < n && i < m; i++)
		printf("%d              | %d \n", producerArray[i], consumerArray[i]);

	if (matchFunc(n, m)) 
		printf("Consumer and Producer Arrays Match!\n");
	
	else 
		printf("Consumer and Producer Arrays Don't Match...\n");
	
	printf("\n");

}

void init()
{
	buffIndex = 0;
	count = 0;
	
	sem_init(&full, 0, 0);   /* creates full semaphore and initialize to 0 */
	sem_init(&empty, 0, N);   /* creates empty semaphore and intitalize to buffer size */

	if (pthread_mutex_init(&lock, NULL) != 0)   /* creates mutex lock and makes its initialized to 0. if not returns error */
		perror("Initialization of mutex failed");

	tid_1 = (pthread_t*)malloc(sizeof(pthread_t) * P);
	tid_2 = (pthread_t*)malloc(sizeof(pthread_t) * C);

	pthread_attr_init(&attr);   /* gets defualt attributes */
}

void currentTime()
{
	time_t currentTime = time(NULL);
	printf("Current Time: %s\n", ctime(&currentTime));
}

int main(int argc, char** argv) 
{
	currentTime();

	if (argc == 7) /* get command line arguments */ 
	{
		printf("Number of Buffers: %s\n", argv[1]);
		printf("Number of Producers: %s\n", argv[2]);
		printf("Number of Consumers: %s\n", argv[3]);
		printf("Number of items Produced by each producer: %s\n", argv[4]);
		printf("Time each Producer Sleeps (seconds): %s\n", argv[5]);
		printf("Time each Consumer Sleeps (seconds): %s\n", argv[6]);

		N = atoi(argv[1]);      /* number of buffers to maintain */
		P = atoi(argv[2]);     /* number of producer threads */
		C = atoi(argv[3]);    /* number of consumer threads */
		X = atoi(argv[4]);   /* number of items produced */

		numConsumed = (P * X) / C;

		Ptime = atoi(argv[5]);   /* time producer thread will sleep after producing an item*/
		Ctime = atoi(argv[6]);   /* time each consumer thread will sleep after consuming an item*/

		buff = (int*)malloc(sizeof(int) * N);
		producerArray = (int*)malloc(sizeof(int) * (P * X));
		consumerArray = (int*)malloc(sizeof(int) * (C * numConsumed));

		init();

		currentTime();
		time_t start = time(NULL);

		int err1;
		int err2;
		int i;
		int j;

		for (i = 0; i < P; i++)
		{
			err1 = pthread_create(&tid_1[i], NULL, &producer, (void*)&tid_1[i]);
			if (err1 != 0)
				perror("Failed to create thread.");
		}

		for (j = 0; j < P; j++)
		{
			err2 = pthread_create(&tid_2[j], NULL, &consumer, (void*)&tid_2[j]);
			if (err2 != 0)
				perror("Failed to create thread.");
		}

		for (i = 0; i < P; i++) {
			pthread_join(tid_1[i], NULL);
		}
		for (j = 0; j < C; j++) {
			pthread_join(tid_2[j], NULL);
		}

		currentTime();

		printArray(P * X, C * numConsumed);
		time_t end = time(NULL);

		int totalTime = end - start;

		printf("Total Runtime: %d seconds\n", totalTime);

		sem_destroy(&full);
		sem_destroy(&empty);
		pthread_mutex_destroy(&lock);
		free(buff);
		free(tid_1);
		free(tid_2);
		
	}

	else
		printf("Wrong amount of arguments. Please enter 6!\n");

	return 0;

}
