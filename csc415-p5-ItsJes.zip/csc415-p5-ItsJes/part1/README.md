# CSC 415 - Project 5 - Producer Consumer - Part 1

## Student Name : Jessica Sendejo

## Student ID : 917443181

## Build Instructions
gcc -I -Wall pthread_race.c -o threadracer -pthread

## Run Instructions
./threadracer

