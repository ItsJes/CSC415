#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h>
#include <sys/time.h>
/**
 * THESE DEFINE VALUES CANNOT BE CHANGED.
 * DOING SO WILL CAUSE POINTS TO BE DEDUCTED
 * FROM YOUR GRADE
 */
 /** BEGIN VALUES THAT CANNOT BE CHANGED */
#define MAX_THREADS 16
#define MAX_ITERATIONS 40
/** END VALUES THAT CANNOT BE CHANGED */

pthread_mutex_t lock;
int numThreads = 0;

/**
 * use this struct as a parameter for the function
 * nanosleep. 
 * For exmaple : nanosleep(&ts, NULL);
 */
struct timespec ts = {0, 123456};

void* adderThreads(void* tid)
{
	pthread_mutex_lock(&lock);
	int val = numThreads;
	int threadId = (*(int*)tid);
	int i;
	for (i = 0; i < MAX_ITERATIONS; i++)
	{
		nanosleep(&ts, NULL);
		val += 3;
		numThreads = val;
		nanosleep(&ts, NULL);
		printf("Current Value written to Global Variables by ADDER thread id: %d is %d\n", threadId, val);
	}

	pthread_mutex_unlock(&lock);
	return NULL;
}

void* subtractorThreads(void* tid)
{
	pthread_mutex_lock(&lock);
	int val = numThreads;
	int threadId = (*(int*)tid);
	int i;
	for (i = 0; i < MAX_ITERATIONS; i++)
	{
		nanosleep(&ts, NULL);
		val -= 3;
		numThreads = val;
		nanosleep(&ts, NULL);
		printf("Current Value written to Global Variables by SUBTRACTOR thread id: %d is %d\n", threadId, val);
	}

	pthread_mutex_unlock(&lock);
	return NULL;
}


int main()
{
	pthread_t thread[MAX_THREADS];
	int err;
	int i;

	if (pthread_mutex_init(&lock, NULL) != 0)
	{
		printf("\n mutex init failed\n");
		return 1;
	}

	for (i = 0; i < MAX_THREADS; i++)
	{
		if (i % 2 == 0)
		{
			err = pthread_create(&thread[i], NULL, &adderThreads, (void*)&thread[i]);
			if (err != 0)
				perror("Failed to create thread.");
		}
		else
		{
			err = pthread_create(&thread[i], NULL, &subtractorThreads, (void*)&thread[i]);
			if (err != 0)
				perror("Failed to create thread.");
		}
	}

	for (i = 1; i < MAX_THREADS; i++)
		pthread_join(thread[i], NULL);

	printf("Final Value of Shared Variable : %d\n", numThreads);

    return 0;
}
